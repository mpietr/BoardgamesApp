create PROCEDURE NowyPracownik
    (nazwP IN VARCHAR,
    nazwaZ IN VARCHAR,
    nazwSz IN VARCHAR,
    placPod IN NUMBER,
    dataZat IN DATE DEFAULT CURRENT_DATE,
    etatP IN VARCHAR DEFAULT 'STAZYSTA')
IS
BEGIN
    INSERT INTO pracownicy(id_prac, nazwisko, id_zesp, id_szefa, zatrudniony, placa_pod, etat) VALUES(
        (SELECT MAX(id_prac)+1 FROM pracownicy),
        nazwP,
        (SELECT id_zesp FROM zespoly WHERE nazwa = nazwaZ),
        (SELECT id_prac FROM pracownicy WHERE nazwisko = nazwSz),
        dataZat,
        placPod,
        etatP
    );
END NowyPracownik;
/

