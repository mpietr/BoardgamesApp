create trigger SPRAWDZURODZENIEGRACZA
    before insert or update
    on GRACZE
    for each row
BEGIN
    IF :NEW.data_urodzenia > trunc(sysdate) THEN
         RAISE_APPLICATION_ERROR(-20001, 'Data z przyszlosci');
    END IF;
END;
/

