create trigger UZUPELNIJIDGRACZA
    before insert
    on GRACZE
    for each row
BEGIN
    IF :NEW.id_gracza IS NULL THEN
        :NEW.id_gracza := id_gracza_seq.NEXTVAL;
    END IF;
END;
/

