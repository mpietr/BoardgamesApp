create view SZEFOWIE (SZEF, LICZBAPODWLADNYCH) as
SELECT (SELECT nazwisko FROM pracownicy WHERE id_prac = s.id_szefa), COUNT(id_szefa)
    FROM pracownicy s GROUP BY (id_szefa)
/

