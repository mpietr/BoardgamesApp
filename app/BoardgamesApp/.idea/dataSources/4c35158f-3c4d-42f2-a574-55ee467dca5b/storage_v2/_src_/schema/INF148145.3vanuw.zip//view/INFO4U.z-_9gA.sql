create view INFO4U as
SELECT "NAZWA","INFO" FROM info_dla_znajomych WHERE nazwa LIKE (SELECT user FROM dual)
/

