create trigger UZUPELNIJIDROZGRYWKI
    before insert
    on ROZGRYWKI
    for each row
BEGIN
    IF :NEW.id_rozgrywki IS NULL THEN
        :NEW.id_rozgrywki := id_rozgrywki_seq.NEXTVAL;
    END IF;
END;
/

