create trigger UZUPELNIJIDROZSZERZENIA
    before insert
    on ROZSZERZENIA
    for each row
BEGIN
    IF :NEW.id_roz IS NULL THEN
        :NEW.id_roz := id_roz_seq.NEXTVAL;
    END IF;
END;
/

