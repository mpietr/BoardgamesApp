create PROCEDURE RaportKadrowy IS
    vLicznik NUMBER;
    vSuma NUMBER;
    CURSOR cEtaty IS
        SELECT nazwa FROM etaty;
    CURSOR cPrac (pEtat VARCHAR) IS
        SELECT nazwisko, placa_pod + NVL(placa_dod, 0) AS pensja
        FROM pracownicy
        WHERE etat = pEtat;
    BEGIN
        FOR vEtat IN cEtaty LOOP
            vLicznik := 0;
            vSuma := 0;
            DBMS_OUTPUT.PUT_LINE('Etat: ' || vEtat.nazwa);
            DBMS_OUTPUT.PUT_LINE('---------------------------');
            FOR vPrac IN cPrac(vEtat.nazwa) LOOP
                vLicznik := vLicznik + 1;
                vSuma := vSuma + vPrac.pensja;
                DBMS_OUTPUT.PUT_LINE(cPrac%ROWCOUNT || '. ' || vPrac.nazwisko || ', pensja: ' || vPrac.pensja);
            END LOOP;
            DBMS_OUTPUT.PUT_LINE('Liczba pracownikow: ' || vLicznik);
            IF vLicznik = 0 THEN
                DBMS_OUTPUT.PUT_LINE('Srednia pensja: brak');
            ELSE
                DBMS_OUTPUT.PUT_LINE('Srednia pensja: ' || vSuma/vLicznik);
            END IF;
            DBMS_OUTPUT.NEW_LINE;
        END LOOP;
END RaportKadrowy;
/

