create trigger WYMUSZAJPLACE
    before insert or update of PLACA_POD
    on PRACOWNICY
    for each row
    when (NEW.etat IS NOT NULL)
DECLARE
 vPlacaMin Etaty.placa_min%TYPE;
 vPlacaMax Etaty.placa_max%TYPE;
BEGIN
 SELECT placa_min, placa_max
 INTO vPlacaMin, vPlacaMax
 FROM Etaty WHERE nazwa = :NEW.etat;
 IF :NEW.placa_pod NOT BETWEEN vPlacaMin AND vPlacaMax THEN
 RAISE_APPLICATION_ERROR(-20001, 'Płaca poza zakresem dla etatu!');
 END IF;
END;
/

