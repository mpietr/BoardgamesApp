create view ZAROBKI as
SELECT id_prac, nazwisko, etat, placa_pod FROM pracownicy p
    WHERE placa_pod < (SELECT placa_pod FROM pracownicy WHERE id_prac = p.id_szefa)
    WITH CHECK OPTION
/

