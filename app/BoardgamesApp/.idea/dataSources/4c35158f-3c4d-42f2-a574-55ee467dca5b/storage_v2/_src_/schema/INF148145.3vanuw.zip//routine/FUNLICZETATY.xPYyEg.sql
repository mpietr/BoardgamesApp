create FUNCTION funLiczEtaty
    RETURN NUMBER AUTHID CURRENT_USER IS
    vIle number;
BEGIN
    select count(*) into vIle from etaty;
    RETURN vIle;
END;
/

