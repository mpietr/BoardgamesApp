create view PLACE_MINIMALNE as
SELECT id_zesp, nazwisko, etat, placa_pod
FROM pracownicy WHERE placa_pod < 700
WITH CHECK OPTION
/

