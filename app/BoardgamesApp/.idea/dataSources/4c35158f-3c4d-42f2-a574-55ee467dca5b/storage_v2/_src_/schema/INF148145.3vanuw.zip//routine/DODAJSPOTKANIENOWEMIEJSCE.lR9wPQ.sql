create PROCEDURE DodajSpotkanieNoweMiejsce
(
    vAdres IN miejsca.adres%TYPE,
    vMiasto IN miejsca.miasto%TYPE,
    vData IN spotkania.data%TYPE
)
IS
    id miejsca.id_miejsca%TYPE;
BEGIN
  INSERT INTO miejsca(adres, miasto)
  VALUES(vAdres, vMiasto)
  RETURNING id_miejsca INTO id;


  INSERT INTO spotkania(data, id_miejsca)
  VALUES(vData, id);

END;
/

