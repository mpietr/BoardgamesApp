create FUNCTION ZmianaWielkosci
    (vIdPrac NUMBER)
    RETURN NUMBER IS
    flag NUMBER;
BEGIN

    UPDATE pracownicy
    SET nazwisko = INITCAP(nazwisko)
    WHERE id_prac = vIdPrac;
    IF SQL%FOUND THEN
        flag := 1;
    ELSE
        flag := 0;
    END IF;
    RETURN flag;
END ZmianaWielkosci;
/

