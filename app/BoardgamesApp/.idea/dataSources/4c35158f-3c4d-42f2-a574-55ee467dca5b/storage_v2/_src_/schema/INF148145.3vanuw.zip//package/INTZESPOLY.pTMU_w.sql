create PACKAGE IntZespoly IS
    PROCEDURE DodajZespol(zId NUMBER, zNazwa VARCHAR, zAdres VARCHAR);
    PROCEDURE UsunZespolPoId(zId NUMBER);
    PROCEDURE UsunZespolPoNazwie(zNazwa VARCHAR);
    PROCEDURE ModyfikujDane(zId NUMBER, zNazwa VARCHAR, zAdres VARCHAR);
    FUNCTION IdZespoluPoNazwie (zNazwa VARCHAR) RETURN NUMBER;
    FUNCTION NazwaZespoluPoId (zId NUMBER) RETURN VARCHAR;
    FUNCTION AdresZespoluPoId (zId NUMBER) RETURN VARCHAR;
END IntZespoly;
/

