create FUNCTION ProcentWygranych (graczID IN NUMBER, graID IN NUMBER)
    RETURN NUMBER
AS
    wszystkieGry NUMBER;
    wygraneGry NUMBER;
BEGIN
    SELECT COUNT(*) INTO wszystkieGry FROM pozycje_graczy_w_grach
    WHERE id_gracza = graczID AND id_gry = graID;
    SELECT COUNT(*) INTO wygraneGry FROM pozycje_graczy_w_grach
    WHERE id_gracza = graczID AND id_gry = graID AND pozycja = 1;
    RETURN ROUND((wygraneGry / wszystkieGry)*100, 2);
END ProcentWygranych;
/

