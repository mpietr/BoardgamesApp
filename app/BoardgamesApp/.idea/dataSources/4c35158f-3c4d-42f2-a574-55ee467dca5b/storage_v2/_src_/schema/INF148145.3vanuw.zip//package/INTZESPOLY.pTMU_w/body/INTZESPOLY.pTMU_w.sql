create PACKAGE BODY IntZespoly IS
    PROCEDURE DodajZespol(zId NUMBER, zNazwa VARCHAR, zAdres VARCHAR) IS
        val NUMBER := 0;
    BEGIN
        SELECT 1 INTO val FROM Zespoly WHERE id_zesp = zId;
        IF val = 1 THEN
            RAISE_APPLICATION_ERROR(-20013, 'Istnieje juz zespol o takim ID');
        END IF;

        INSERT INTO Zespoly (id_zesp, nazwa, adres) VALUES(
        zId,
        zNazwa,
        zAdres
        );
        IF SQL%FOUND THEN
            DBMS_OUTPUT.PUT_LINE ('Dodano rekord');
        ELSE
            DBMS_OUTPUT.PUT_LINE ('Nie wstawiono rekordu');

        END IF;
    END DodajZespol;

    PROCEDURE UsunZespolPoId(zId NUMBER) IS
    BEGIN
        DELETE FROM Zespoly
        WHERE id_zesp = zId;
        IF SQL%FOUND THEN
            DBMS_OUTPUT.PUT_LINE ('Usunieto rekord');
        ELSE
            DBMS_OUTPUT.PUT_LINE ('Nie udało się usunąć rekordu');
              RAISE_APPLICATION_ERROR(-20012, 'Nie istnieje zespol o takim ID');
        END IF;
    END UsunZespolPoId;

    PROCEDURE UsunZespolPoNazwie(zNazwa VARCHAR) IS
    BEGIN
        DELETE FROM Zespoly
        WHERE nazwa LIKE zNazwa;
        IF SQL%FOUND THEN
            DBMS_OUTPUT.PUT_LINE ('Usunieto rekord');
        ELSE
            DBMS_OUTPUT.PUT_LINE ('Nie udało się usunąć rekordu');
            RAISE_APPLICATION_ERROR(-20011, 'Nie istnieje zespol o takiej nazwie');
        END IF;
    END UsunZespolPoNazwie;

    PROCEDURE ModyfikujDane(zId NUMBER, zNazwa VARCHAR, zAdres VARCHAR) IS
    BEGIN
        UPDATE Zespoly
        SET nazwa = zNazwa,
            adres = zAdres
        WHERE id_zesp = zId;
        IF SQL%FOUND THEN
            DBMS_OUTPUT.PUT_LINE ('Zmodywikowano rekord');
        ELSE
            DBMS_OUTPUT.PUT_LINE ('Nie udało się zmodyfikować rekordu');
             RAISE_APPLICATION_ERROR(-20012, 'Nie istnieje zespol o takim ID');
        END IF;
    END ModyfikujDane;

    FUNCTION IdZespoluPoNazwie (zNazwa VARCHAR)
    RETURN NUMBER IS
    zId NUMBER;
    BEGIN
        SELECT id_zesp
        INTO zId
        FROM Zespoly
        WHERE nazwa LIKE zNazwa;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20011, 'Nie istnieje zespol o takiej nazwie');
    RETURN zId;
    END IdZespoluPoNazwie;

    FUNCTION NazwaZespoluPoId (zId NUMBER)
    RETURN VARCHAR IS
    zNazwa VARCHAR(100);
    BEGIN
        SELECT nazwa
        INTO zNazwa
        FROM Zespoly
        WHERE id_zesp = zId;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20012, 'Nie istnieje zespol o takim ID');
    RETURN zNazwa;
    END NazwaZespoluPoId;

    FUNCTION AdresZespoluPoId (zId NUMBER)
    RETURN VARCHAR IS
    zAdres VARCHAR(100);
    BEGIN
        SELECT adres
        INTO zAdres
        FROM Zespoly
        WHERE id_zesp = zId;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20012, 'Nie istnieje zespol o takim ID');
    RETURN zAdres;
    END AdresZespoluPoId;

END IntZespoly;
/

