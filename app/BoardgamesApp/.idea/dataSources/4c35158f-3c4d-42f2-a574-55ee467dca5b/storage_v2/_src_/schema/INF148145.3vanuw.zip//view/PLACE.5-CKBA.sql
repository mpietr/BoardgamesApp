create view PLACE (ID_ZESP, SREDNIA, MINIMUM, MAKSIMUM, FUNDUSZ, L_PENSJI, L_DODATKOW) as
SELECT id_zesp, AVG(placa_pod + NVL(placa_dod, 0)), MIN(placa_pod + NVL(placa_dod, 0)),
    MAX(placa_pod + NVL(placa_dod, 0)), SUM(placa_pod + NVL(placa_dod, 0)), COUNT(placa_pod), COUNT(placa_dod)
    FROM pracownicy GROUP BY id_zesp
/

