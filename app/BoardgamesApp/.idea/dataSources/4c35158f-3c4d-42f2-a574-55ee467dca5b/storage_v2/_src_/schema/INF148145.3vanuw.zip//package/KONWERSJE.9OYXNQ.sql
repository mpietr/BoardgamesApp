create PACKAGE Konwersje IS
    FUNCTION Cels_To_Fahr (cels NUMBER)
        RETURN NUMBER;
    FUNCTION Fahr_to_Cels (fahr NUMBER)
        RETURN NUMBER;
END Konwersje;
/

