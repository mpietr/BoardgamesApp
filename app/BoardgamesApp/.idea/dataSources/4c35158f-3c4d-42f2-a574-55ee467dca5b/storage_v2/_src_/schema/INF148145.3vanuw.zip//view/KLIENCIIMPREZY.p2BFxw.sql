create view KLIENCIIMPREZY (KLIENT_I_JEGO_IMPREZA, STAN_ZAPLATY) as
select k.imie || ' ' || k.nazwisko || ': ' || x.miejsce, x.stan_oplaty from
(select r.id_klienta, (i.kontynent || ' ' || i.kraj || ' ' || i.miasto) as miejsce,
case
    when r.zaliczka = r.cena then 'zaplacona'
    when r.zaliczka between 1 and r.cena - 1 then 'zaliczka'
    else 'brak wplaty'
end as stan_oplaty
from rezerwacje r join imprezy i on r.impreza = i.symbol_imprezy) x join klienci k using(id_klienta)
with read only
/

