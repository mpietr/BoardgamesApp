create view POZYCJE_GRACZY_W_GRACH as
SELECT gr_w_rozgr_spot.id_gracza AS id_gracza, zestawy.gry_id_gry AS id_gry, gr_w_rozgr_spot.pozycja AS pozycja
    FROM gr_w_rozgr_spot JOIN rozgrywki ON gr_w_rozgr_spot.id_rozgrywki = rozgrywki.id_rozgrywki
    JOIN zestawy ON rozgrywki.id_zestawu = zestawy.id_zestawu
/

