create trigger UZUPELNIJIDGRY
    before insert
    on GRY
    for each row
BEGIN
    IF :NEW.id_gry IS NULL THEN
        :NEW.id_gry := id_gry_seq.NEXTVAL;
    END IF;
END;
/

