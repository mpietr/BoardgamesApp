create trigger UZUPELNIJIDZESTAWU
    before insert
    on ZESTAWY
    for each row
BEGIN
    IF :NEW.id_zestawu IS NULL THEN
        :NEW.id_zestawu := id_zestawu_seq.NEXTVAL;
    END IF;
END;
/

