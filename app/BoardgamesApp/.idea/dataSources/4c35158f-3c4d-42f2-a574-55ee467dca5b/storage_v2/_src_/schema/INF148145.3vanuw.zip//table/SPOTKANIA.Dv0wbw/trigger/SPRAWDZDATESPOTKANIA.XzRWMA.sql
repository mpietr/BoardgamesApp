create trigger SPRAWDZDATESPOTKANIA
    before insert or update
    on SPOTKANIA
    for each row
BEGIN
    IF :NEW.data > trunc(sysdate) THEN
         RAISE_APPLICATION_ERROR(-20001, 'Data z przyszlosci');
    END IF;
END;
/

