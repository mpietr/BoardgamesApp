create trigger UZUPELNIJIDMIEJSCA
    before insert
    on MIEJSCA
    for each row
BEGIN
    IF :NEW.id_miejsca IS NULL THEN
        :NEW.id_miejsca := id_miejsca_seq.NEXTVAL;
    END IF;
END;
/

