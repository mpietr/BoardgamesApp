create view PARY as
(SELECT a.id_produktu as aid, b.id_produktu as bid, a.id_przepisu
FROM
skladniki_przepisow a JOIN skladniki_przepisow b ON a.id_przepisu=b.id_przepisu
WHERE a.id_produktu < b.id_produktu)
with read only
/

