create PACKAGE BODY Konwersje IS
    FUNCTION Cels_To_Fahr (cels NUMBER)
        RETURN NUMBER IS
            fahr NUMBER;
    BEGIN
        fahr := 9/5 * cels + 32;
    END Cels_To_Fahr;

    FUNCTION Fahr_To_Cels (fahr NUMBER)
        RETURN NUMBER IS
            cels NUMBER;
    BEGIN
        cels := 5/9 * (fahr - 32);
    END Fahr_To_Cels;
END Konwersje;
/

