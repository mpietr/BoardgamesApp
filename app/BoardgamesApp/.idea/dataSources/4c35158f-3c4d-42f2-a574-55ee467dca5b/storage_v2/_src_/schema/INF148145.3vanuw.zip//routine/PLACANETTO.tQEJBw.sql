create FUNCTION PlacaNetto
    (placaB IN NUMBER,
    proc IN NUMBER DEFAULT 20)
    RETURN NUMBER IS
    placaN NUMBER;
BEGIN
    placaN := placaB * (100-proc) / 100;
    RETURN placaN;
END PlacaNetto;
/

