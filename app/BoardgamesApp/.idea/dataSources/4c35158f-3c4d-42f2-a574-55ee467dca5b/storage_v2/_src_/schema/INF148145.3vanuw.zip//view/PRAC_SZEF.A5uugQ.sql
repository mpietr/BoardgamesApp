create view PRAC_SZEF as
SELECT p.id_prac, p.id_szefa, p.nazwisko, p.etat, s.nazwisko 
 FROM pracownicy p JOIN pracownicy s ON p.id_szefa = s.id_prac
/

