create trigger UZUPELNIJIDSPOTKANIA
    before insert
    on SPOTKANIA
    for each row
BEGIN
    IF :NEW.id_spotkania IS NULL THEN
        :NEW.id_spotkania := id_spotkania_seq.NEXTVAL;
    END IF;
END;
/

