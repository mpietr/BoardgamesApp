create PROCEDURE PokazPracownikowEtatu
    (pEtat IN VARCHAR) IS 
        CURSOR cPrac (pEtat VARCHAR) IS
        SELECT nazwisko, placa_pod + NVL(placa_dod, 0) AS pensja
        FROM pracownicy
        WHERE etat = pEtat;
    BEGIN
        FOR vPrac IN cPrac(PEtat) LOOP
            DBMS_OUTPUT.PUT_LINE(vPrac.nazwisko);
        END LOOP;
END PokazPracownikowEtatu;
/

